package com.microservices.storage;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StorageServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
