package com.microservices.itemdetailsreactive;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ItemDetailsReactiveApplicationTests {

	@Test
	void contextLoads() {
	}

}
